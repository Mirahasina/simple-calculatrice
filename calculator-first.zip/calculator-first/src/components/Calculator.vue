<template>
    <div class="calculator">
      <div class="display">{{ display }}</div>
      <div class="buttons">
        <button v-for="button in buttons" :key="button" @click="handleButton(button)">{{ button }}</button>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Calculator',
    data() {
      return {
        display: '0',
        currentNumber: 0,
        previousNumber: null,
        currentOperator: null,
        buttons: ['1', '2', '3', '+', '4', '5', '6', '-', '7', '8', '9', '*', '0', '.', '/', '%', '=', 'DEL']
      }
    },
    methods: {
      handleButton(button) {
        if (button === 'DEL') {
          this.display = '0';
          this.currentNumber = 0;
          this.currentOperator = null;
        } else if (button === '=' && this.currentOperator) {
          this.calculate();
        } else if (['+', '-', '*', '/', '%'].includes(button)) {
          this.setOperator(button);
        }else if (button === '.') {
          if (!this.display.includes('.')) {
            this.updateDisplay(button);
          }
        } else {
          this.updateDisplay(button);
        }
      },
      updateDisplay(value) {
        if (this.display === '0') {
          this.display = value;
        } else {
          this.display += value;
        }
        this.currentNumber = parseFloat(this.display);
      },
      setOperator(operator) {
      this.previousNumber = this.currentNumber;
      this.currentOperator = operator;
      this.display = `${this.previousNumber} ${operator} ${this.currentNumber}`;
      this.display = '';
    },
      calculate() {
        const previousNumber = this.previousNumber;
        const operator = this.currentOperator;
        let result;
        switch (operator) {
          case '+':
            result = previousNumber + this.currentNumber;
            break;
          case '-':
            result = previousNumber - this.currentNumber;
            break;
          case '*':
            result = previousNumber * this.currentNumber;
            break;
          case '/':
            result = previousNumber / this.currentNumber;
            break;
          case '%':
            result = previousNumber % this.currentNumber;
            break;
          default:
            return;
        }
        this.display = String(result);
        this.currentNumber = result;
        this.currentOperator = null;
        this.previousNumber = null;
      },
      clear() {
        this.display = '0';
        this.currentNumber = 0;
        this.currentOperator = null;
        this.previousNumber = null;
      }
    }
  }
  </script>
  
  <style src="./../../public/css/output.css"></style>
  