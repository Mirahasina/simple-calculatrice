methods: {
    handleButton(button) {
      if (button === 'DEL') {
        this.display = '0';
        this.currentNumber = 0;
        this.currentOperator = null;
      } else if (button === '=' && this.currentOperator) {
        this.calculate();
      } else if (['+', '-', '*', '/', '%'].includes(button)) {
        this.setOperator(button);
      } else if (button === '.') {
        if (!this.display.includes('.')) {
          this.updateDisplay(button);
        }
      } else {
        this.updateDisplay(button);
      }
    },
    updateDisplay(value) {
      if (this.display === '0') {
        this.display = value;
      } else {
        this.display += value;
      }
      this.currentNumber = parseFloat(this.display);
    },
    setOperator(operator) {
      this.currentOperator = operator;
      this.currentNumber = parseFloat(this.display);
      this.display = '0';
    },
    calculate() {
      const previousNumber = this.currentNumber;
      const operator = this.currentOperator;
      let result;
      switch (operator) {
        case '+':
          result = previousNumber + this.currentNumber;
          break;
        case '-':
          result = previousNumber - this.currentNumber;
          break;
        case '*':
          result = previousNumber * this.currentNumber;
          break;
        case '/':
          result = previousNumber / this.currentNumber;
          break;
        case '%':
          result = previousNumber % this.currentNumber;
          break;
        default:
          return;
      }
      this.display = String(result);
      this.currentNumber = result;
      this.currentOperator = null;
    },
    clear() {
      this.display = '0';
      this.currentNumber = 0;
      this.currentOperator = null;
    }
  }
  